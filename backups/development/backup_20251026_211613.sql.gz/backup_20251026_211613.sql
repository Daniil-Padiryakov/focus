--
-- PostgreSQL database dump
--

\restrict ROrWwHQmCS3Dcgqx0V1F7gnBIIPVmXcAJ8RvKIN4SghKL7lAvHFzcu03upVYLUB

-- Dumped from database version 14.19
-- Dumped by pg_dump version 14.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: focus; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA focus;


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: trigger_set_timestamp(); Type: FUNCTION; Schema: focus; Owner: -
--

CREATE FUNCTION focus.trigger_set_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION trigger_set_timestamp(); Type: COMMENT; Schema: focus; Owner: -
--

COMMENT ON FUNCTION focus.trigger_set_timestamp() IS 'Автоматически обновляет updated_at timestamp';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- Name: pomodoros; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pomodoros (
    pomodoro_id integer NOT NULL,
    user_id integer NOT NULL,
    planned_duration integer NOT NULL,
    actual_duration integer,
    start_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    end_time timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT check_actual_duration CHECK (((actual_duration IS NULL) OR (actual_duration <= (planned_duration * 3)))),
    CONSTRAINT check_end_after_start CHECK (((end_time IS NULL) OR (end_time >= start_time))),
    CONSTRAINT check_planned_duration CHECK (((planned_duration >= 60) AND (planned_duration <= 7200)))
);


--
-- Name: COLUMN pomodoros.user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.pomodoros.user_id IS 'User who owns this pomodoro';


--
-- Name: COLUMN pomodoros.planned_duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.pomodoros.planned_duration IS 'Planned duration in seconds (e.g., 1500 = 25min)';


--
-- Name: COLUMN pomodoros.actual_duration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.pomodoros.actual_duration IS 'Actual duration in seconds (if completed)';


--
-- Name: COLUMN pomodoros.start_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.pomodoros.start_time IS 'When pomodoro started';


--
-- Name: COLUMN pomodoros.end_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.pomodoros.end_time IS 'When pomodoro ended (if completed)';


--
-- Name: pomodoros_pomodoro_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pomodoros_pomodoro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pomodoros_pomodoro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pomodoros_pomodoro_id_seq OWNED BY public.pomodoros.pomodoro_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_login_at timestamp with time zone,
    deleted_at timestamp with time zone,
    CONSTRAINT check_deleted_after_created CHECK (((deleted_at IS NULL) OR (deleted_at >= created_at))),
    CONSTRAINT check_email_format CHECK (((email)::text ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Z|a-z]{2,}$'::text)),
    CONSTRAINT check_updated_after_created CHECK ((updated_at >= created_at))
);


--
-- Name: COLUMN users.user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.user_id IS 'User ID (auto-increment)';


--
-- Name: COLUMN users.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.email IS 'User email (unique, for login)';


--
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.password_hash IS 'Bcrypt password hash';


--
-- Name: COLUMN users.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.created_at IS 'Created timestamp (UTC)';


--
-- Name: COLUMN users.updated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.updated_at IS 'Updated timestamp (UTC)';


--
-- Name: COLUMN users.last_login_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.last_login_at IS 'Last login timestamp';


--
-- Name: COLUMN users.deleted_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.deleted_at IS 'Soft delete timestamp';


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- Name: pomodoros pomodoro_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pomodoros ALTER COLUMN pomodoro_id SET DEFAULT nextval('public.pomodoros_pomodoro_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
7	20251025143703_create_users_table.ts	1	2025-10-26 15:53:08.677+00
8	20251025145201_create_pomodoros_table.ts	1	2025-10-26 15:53:08.697+00
9	20251026160705_add_performance_indexes.ts	2	2025-10-26 16:16:48.243+00
10	20251026160957_add_data_integrity_constraints.ts	2	2025-10-26 16:16:48.247+00
\.


--
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: pomodoros; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pomodoros (pomodoro_id, user_id, planned_duration, actual_duration, start_time, end_time, created_at, updated_at) FROM stdin;
1	1	1500	1500	2025-10-23 09:00:00+00	2025-10-23 09:25:00+00	2025-10-26 15:53:08.563753+00	2025-10-26 15:53:08.563753+00
2	1	1500	1500	2025-10-23 09:35:00+00	2025-10-23 10:00:00+00	2025-10-26 15:53:08.563753+00	2025-10-26 15:53:08.563753+00
3	1	1500	1500	2025-10-23 10:10:00+00	2025-10-23 10:35:00+00	2025-10-26 15:53:08.563753+00	2025-10-26 15:53:08.563753+00
4	1	1500	1500	2025-10-23 10:45:00+00	2025-10-23 11:10:00+00	2025-10-26 15:53:08.563753+00	2025-10-26 15:53:08.563753+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (user_id, email, password_hash, created_at, updated_at, last_login_at, deleted_at) FROM stdin;
1	demo@example.com	$2b$10$0lCd/rAYe0IfW4Fo9StFTumqZtTrrrdV0YIjA7LyBtHxSFqnpyRK2	2025-10-26 15:53:08.546144+00	2025-10-26 15:53:08.546144+00	2025-10-26 15:53:08.546144+00	\N
2	admin@example.com	$2b$10$0lCd/rAYe0IfW4Fo9StFTumqZtTrrrdV0YIjA7LyBtHxSFqnpyRK2	2025-10-26 15:53:08.546144+00	2025-10-26 15:53:08.546144+00	\N	\N
\.


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 10, true);


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- Name: pomodoros_pomodoro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pomodoros_pomodoro_id_seq', 4, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_user_id_seq', 3, true);


--
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- Name: pomodoros pomodoros_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pomodoros
    ADD CONSTRAINT pomodoros_pkey PRIMARY KEY (pomodoro_id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: idx_pomodoros_start_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pomodoros_start_time ON public.pomodoros USING btree (start_time);


--
-- Name: idx_pomodoros_start_time_brin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pomodoros_start_time_brin ON public.pomodoros USING brin (start_time);


--
-- Name: idx_pomodoros_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pomodoros_user_date ON public.pomodoros USING btree (user_id, start_time DESC);


--
-- Name: idx_pomodoros_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pomodoros_user_id ON public.pomodoros USING btree (user_id);


--
-- Name: idx_pomodoros_user_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pomodoros_user_start ON public.pomodoros USING btree (user_id, start_time);


--
-- Name: idx_users_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_active ON public.users USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_users_active_last_login; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_active_last_login ON public.users USING btree (last_login_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: pomodoros set_pomodoros_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_pomodoros_updated_at BEFORE UPDATE ON public.pomodoros FOR EACH ROW EXECUTE FUNCTION focus.trigger_set_timestamp();


--
-- Name: users set_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION focus.trigger_set_timestamp();


--
-- Name: pomodoros pomodoros_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pomodoros
    ADD CONSTRAINT pomodoros_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict ROrWwHQmCS3Dcgqx0V1F7gnBIIPVmXcAJ8RvKIN4SghKL7lAvHFzcu03upVYLUB

